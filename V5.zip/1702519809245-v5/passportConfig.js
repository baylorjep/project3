const LocalStrategy = require("passport-local").Strategy;
const { Pool } = require('pg');
const bcrypt = require("bcrypt");
const knex = require("knex")({
  client: "pg",
  connection: {
      host: process.env.RDS_HOSTNAME || "localhost",
      user: process.env.RDS_USERNAME || "postgres",
      password: process.env.RDS_PASSWORD || "admin",
      database: process.env.RDS_DB_NAME ||"ebdb",
      port: process.env.RDS_PORT || 5432,
      ssl: process.env.DB_SSL ? {rejectUnauthorized: false}: false
  }
})

function initialize(passport) {
  console.log("Initialized");

  const authenticateUser = async (username, password, done) => {
    console.log(username, password);
    try {
      const results = await knex('userlogin').where('username', '=', username);

      if (results.length > 0) {
        const user = results[0];

        bcrypt.compare(password, user.password, (err, isMatch) => {
          if (err) {
            console.log(err);
          }
          if (isMatch) {
            return done(null, user);
          } else {
            // Password is incorrect
            return done(null, false, { message: "Password is incorrect" });
          }
        });
      } else {
        // No user
        return done(null, false, { message: "No user with that Username/Password combination" });
      }
    } catch (err) {
      console.error(err);
      return done(err);
    }
  };

  passport.use(
    new LocalStrategy(
      { usernameField: "username", passwordField: "password" },
      authenticateUser
    )
  );

  passport.serializeUser((user, done) => done(null, user.username));

  passport.deserializeUser(async (username, done) => {
    try {
      const results = await knex('userlogin').where('username', '=', username);

      if (results.length > 0) {
        console.log(`Username is ${results[0].username}`);
        return done(null, results[0]);
      } else {
        return done(null, false, { message: "No user found with that Username" });
      }
    } catch (err) {
      console.error(err);
      return done(err);
    }
  });
}

module.exports = initialize;