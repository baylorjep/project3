const express = require("express");
const { Pool } = require('pg');
let app = express();
const bcrypt = require("bcrypt")
let path = require("path");
const passport = require("passport");
const flash = require("express-flash");
const session = require("express-session");

const port = process.env.PORT || 5501;

const initializePassport = require("./passportConfig");

initializePassport(passport);

app.set("view engine", "ejs");

app.use(express.urlencoded({ extended:false}));

app.use(express.static(path.join(__dirname, 'public')));


app.use(
  session({
    // Key we want to keep secret which will encrypt all of our information
    secret: process.env.SESSION_SECRET || 'javaiscool',
    // Should we resave our session variables if nothing has changes which we dont
    resave: false,
    // Save empty value if there is no vaue which we do not want to do
    saveUninitialized: false
  })
);
// Function inside passport which initializes passport
app.use(passport.initialize());
// Store our variables to be persisted across the whole session. Works with app.use(Session) above
app.use(passport.session());
app.use(flash());

const knex = require("knex")({
    client: "pg",
    connection: {
        host: "awseb-e-py4xqpbmwt-stack-awsebrdsdatabase-1bdfpcoqujt2.cbr54hfcvm0p.us-east-2.rds.amazonaws.com" || "localhost",
        user: "ebroot1" || "postgres",
        password: "iLoveGroup3" || "admin",
        database: "ebdb" ||"ebdb",
        port: process.env.RDS_PORT || 5432,
        ssl: process.env.DB_SSL ? {rejectUnauthorized: false}: false
    }
})

app.get('/', (req, res) => {
    res.render('index.ejs'); 
  });

app.get('/form', (req, res) => {
    res.render('inner-page.ejs'); 
  });

  app.get('/adminview', (req, res) => {
    knex.select().from("restaurants").then(restaurants => {
    res.render('viewallrecords.ejs', { restaurants: restaurants }); 
    })
  });

  app.get("/adminview/:vote_id", (req, res) => {
    const vote_id = parseInt(req.params.vote_id, 10);
    knex.select().from("restaurants").where('vote_id', vote_id).orderBy('vote_id')
    .then(restaurants => {
      res.render('viewallrecords.ejs', {restaurants: restaurants});
  
    });
    
  });

  app.get("/editrecord", (req, res) => {
    knex.select().from("restaurants").where("vote_id", req.query.id).then(restaurants => {
        res.render("editrecord.ejs", {restaurants: restaurants});
    }).catch(err => {
        console.log(err);
        res.status(500).json({err});
    });    
});  
app.post("/editrecord", (req, res) => {
  knex("restaurants").where("vote_id", req.body.id).update({
      first_vote: req.body.first_vote,
      second_vote: req.body.second_vote,
      third_vote: req.body.third_vote
  }).then(restaurants => {
      res.redirect("/");
  });    
});       

app.get("/deleterecord", (req, res) => {
  const vote_id = req.query.id2;
  knex('restaurants').where("vote_id", vote_id).del().then(restaurants => {
      res.render("viewallrecords.ejs", {restaurants: restaurants});
  }).catch(err => {
      console.log(err);
      res.status(500).json({err});
  });    
});

app.post("/deleterecord/:vote_id", (req, res) => {
  
  knex("restaurants").where("vote_id", req.params.id2).del().then(restaurants => {
      res.redirect("/");
  }).catch(err => {
      console.log(err);
      res.status(500).json({err});
  })
});  

app.get('/login', checkAuthenticated, (req, res) => {
  console.log(req.session.flash.error);
    res.render('login.ejs'); 
  });
  app.get('/createuser', checkAuthenticated, (req, res) => {
    res.render('createuser.ejs'); 
  });
  app.get('/access-granted', checkNotAuthenticated, (req, res) => {
    console.log(req.isAuthenticated());
    console.log('Username:', req.user.username)
    res.render('justloggedin.ejs', {user: req.user.username}); 
  });
  //testing our tables
  // app.get('/adminview', (req, res) => {
   // res.render('viewallrecords.ejs');  });
  /*app.get("/adminview", (req, res) => {
      knex.select("username", "password").from('userlogin').then(userinfo => {
          res.render("viewallrecords.ejs", {myusers: userinfo});
      }).catch(err => {
          console.log(err);
          res.status(500).json({err});
      });
  });
  
  app.get("/adminview/chooseuser/:userName", (req, res) => {
      knex.select("username", "password").from('userlogin').where("username", req.params.userName).then(userinfo => {
          res.render("viewallrecords.ejs", {myusers: userinfo});
      }).catch(err => {
          console.log(err);
          res.status(500).json({err});
      });
  });
*/
//end table testing

 //modify testing:

 /* app.get('/modify', checkNotAuthenticated, (req, res) => {
    res.render('modifyuser.ejs');
  });*/

app.get("/modify", (req, res) => {
    res.render("modifyuser.ejs", {});
});

app.get("/chooseUser/:userName", (req, res) => {
  knex.select("username", "password").from('userlogin').where("username", req.params.userName).then(userinfo => {
      res.render("viewallrecords.ejs", {myusers: userinfo});
  }).catch(err => {
      console.log(err);
      res.status(500).json({err});
  });
});

app.get("/editUser", (req, res) => {       
    knex.select("username", "password").from("userlogin").where("username", req.query.userName).then(userinfo => {
        res.render("makechange.ejs", {myusers: userinfo});
    }).catch(err => {
        console.log(err);
        res.status(500).json({err});
    });    
});


app.post("/editUser", (req, res) => {
    knex("userlogin").where("username", req.body.userName).update({
        username: req.body.newusername,
        password: req.body.password
    }).then(() => {
      // Once the update is complete, redirect the user
      res.redirect("/access-granted");
  })
  .catch(error => {
      // Handle any errors that occur during the database update
      console.error(error);
      res.status(500).send("Internal Server Error");
  });
});

//end modify testing

  app.get("/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        console.error(err);
        return res.redirect("/");
      }
      res.render("index.ejs", { message: "You have logged out successfully!" });
    });
  });

  app.post("/form", (req, res) => {
    knex("restaurants").insert({
      first_vote: req.body.first_vote,
      second_vote: req.body.second_vote,
      third_vote: req.body.third_vote
 
   }).then(() => {
    // Once the update is complete, redirect the user
    res.redirect("/form")
   }).catch(err => {
       console.log(err);
       res.status(500).json({ err });
   });
 });
  

  app.post('/createuser', async (req, res) => {
    let { username, password, password2 } = req.body;
    let errors = [];
  
    console.log({
      username,
      password,
      password2
    });
  
    if (!username || !password || !password2) {
      errors.push({ message: "Please enter all fields" });
    }
  
    if (password.length < 5) {
      errors.push({ message: "Password must be at least 5 characters long" });
    }
  
    if (password !== password2) {
      errors.push({ message: "Passwords Do Not Match" });
    }
  
    if (errors.length > 0) {
      res.render("createuser", { errors, username, password, password2 });
    } else {
      let hashedPassword = await bcrypt.hash(password, 10);
      console.log(hashedPassword);
  
      try {
        const existingUser = await knex
          .select('*')
          .from('userlogin')
          .where('username', '=', username);
  
        if (existingUser.length > 0) {
          return res.render("createuser", {
            errors: [{ message: "Username Already In Use" }]
          });
        } else {
          const newUser = await knex('userlogin')
            .insert({ username, password: hashedPassword })
            .returning(['username', 'password']);
  
          console.log(newUser);
  
          req.flash("success_msg", "Account Created Successfully! Please Log In.");
          return res.redirect("/login");
        }
      } catch (err) {
        console.error(err);
        res.status(500).send("Internal Server Error");
      }
    }
  });

  /*START Modify Functionality

app.post('/modify', checkNotAuthenticated, async (req, res) => {
  console.log('User:', req.user)
  const { newUsername, newPassword } = req.body;
  const errors = [];
  console.log("New Username: "+newUsername+ ", Pasword:"+ newPassword )
  // Validate input (you can add more validation logic as needed)
  if (!newUsername || !newPassword) {
    errors.push({ message: 'Please enter both new username and password.' });
  }

  // Handle errors
  if (errors.length > 0) {
    return res.render('modifyuser.ejs', { errors });
  }

  try {
    // Update user information in the database
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    const updatedUser = await knex('userlogin')
    .where({ username: req.user.username })
    .update({ username: newUsername, password: hashedPassword })
    .returning('*');

    if (updatedUser.length === 0) {
      return res.render('modify', {
        errors: [{ message: 'Failed to update user information' }],
        newUsername,
        newPassword,
      });
    }
    console.log('Updated User:', updatedUser);

    // Redirect to a success page or another relevant page
    return res.redirect('/access-granted'); // You can change this to the desired redirect URL
  } catch (error) {
    console.error(error);
    return res.status(500).send('Internal Server Error');
  }
});

  
// End modify*/

  app.post(
    "/login",
    passport.authenticate("local", {
      successRedirect: "/access-granted",
      failureRedirect: "/login",
      failureFlash: true,
      badRequestMessage: 'Both fields are required'
    })
  );
  
  function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()&& req.path !== '/createuser') {
      return res.redirect("/access-granted");
    }
    next();
  }
  
  function checkNotAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
      return next();
    }
    res.redirect("/login");
  }


app.listen(port, () => console.log("I am listening"));



const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'ebdb',
  password: 'admin',
  port: 5432,
});
  app.get('/calculatevotes', async (req, res) => {
    try {
      // Step 1: Retrieve Data from the Database
      const result = await pool.query('SELECT * FROM restaurants');
      console.log(result.rows);
      // Step 2: Calculate Points for Each Restaurant
      const restaurants = result.rows.map((row) => ({
        restaurant: row.first_vote,
        points: 5, // 5 points for first-place vote
      }));
      result.rows.forEach((row) => {
        restaurants.push({ restaurant: row.second_vote, points: 3 }); // 3 points for second-place vote
        restaurants.push({ restaurant: row.third_vote, points: 1 }); // 1 point for third-place vote
      });
      // Step 3: Aggregate Total Points for Each Restaurant
      const pointsMap = new Map();
      restaurants.forEach(({ restaurant, points }) => {
        pointsMap.set(restaurant, (pointsMap.get(restaurant) || 0) + points);
      });
      // Step 4: Rank Restaurants
      const rankedRestaurants = Array.from(pointsMap.entries()).sort((a, b) => b[1] - a[1]);
      console.log(rankedRestaurants);
      res.render("votingResults.ejs", { rankedRestaurants });
    } catch (error) {
      console.error(error.stack);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });